

export { default } from './MainContent';
