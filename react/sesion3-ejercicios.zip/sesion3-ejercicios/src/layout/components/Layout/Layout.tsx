
import Heading from "../../../shared/components/Heading";
import LayoutContener from "../../../shared/components/LayoutContener";
import TextContener from "../../../shared/components/Text/TextContener";
import Header from "../Header/Header";
import MainContent from "../MainContent";



const Layout = (): React.ReactElement => {
  return(
    <LayoutContener>
      <Header>
        <img src="./logo.svg"></img>
        <Heading>bonÀrea App</Heading>
      </Header>
      <MainContent>
        <Heading level={2}>Continguts</Heading>
        <TextContener>A bonÀrea estem aprenent bones pràctiques en frontends amb un senyor amb accent del sud que diu que sap coses.</TextContener>
      </MainContent>
    </LayoutContener>
  )
}

export default Layout;
