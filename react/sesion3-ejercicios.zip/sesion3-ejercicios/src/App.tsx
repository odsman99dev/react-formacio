import Layout from "./layout/components/Layout/Layout";



function App(): React.ReactElement {
  return <Layout></Layout>
}

export default App;
