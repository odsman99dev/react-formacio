import "./Heading.scss";

import { PropsWithChildren } from "react";



interface HeadingProps {
  level?: number;
}

const Heading = ({level = 1, children}: PropsWithChildren<HeadingProps>): React.ReactElement => {
  const Tag = `h${level}` as keyof React.JSX.IntrinsicElements;
  return <Tag className="heading-contener">{children}</Tag>
}

export default Heading;
