export { default } from './Heading';
