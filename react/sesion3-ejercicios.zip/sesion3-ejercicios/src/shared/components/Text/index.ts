
export { default } from './TextContener';
